package minha.app

import grails.gorm.services.Service

@Service(Carro)
interface CarroService {

    Carro get(Serializable id)

    List<Carro> list(Map args)

    Long count()

    void delete(Serializable id)

    Carro save(Carro carro)

}