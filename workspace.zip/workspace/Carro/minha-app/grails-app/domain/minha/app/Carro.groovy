package minha.app

class Carro {

String cor
Integer qtPorta
String tpMotor
String modelo
String marca

    static constraints = {

        cor nullable: false
        qtPorta min: 2, max: 5
        tpMotor inList: ['Gasolina','Diesel','Eletrico','Hibrido']
        modelo nullable: false
        marca nullable: false
       }

       static mapping = {

        version false
    }
}
