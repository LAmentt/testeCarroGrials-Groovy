package minha.app

class UrlMappings {

    static mappings = {
        "/$controller/$action?/$id?(.$format)?"{
            constraints {
                // apply constraints here
            }
        }

        "/carro"(resources: 'carro')


        "/"(view:"/index")
        "500"(view:'/error')
        "404"(view:'/notFound')
    }
}
