package minha.app

import grails.validation.ValidationException
import static org.springframework.http.HttpStatus.*

class CarroController {

    CarroService carroService

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

    def index(Integer max) {
        params.max = Math.min(max ?: 10, 100)
        respond carroService.list(params), model:[carroCount: carroService.count()]
    }

    def show(Long id) {
        respond carroService.get(id)
    }

    def create() {
        respond new Carro(params)
    }

    def save(Carro carro) {

        if (carro == null) {
            notFound()
            return
        }

        try {
            carroService.save(carro)
        } catch (ValidationException e) {
            respond carro.errors, view:'create'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.created.message', args: [message(code: 'carro.label', default: 'Carro'), carro.id])
                redirect carro
            }
            '*' { respond carro, [status: CREATED] }
        }
    }

    def edit(Long id) {
        respond carroService.get(id)
    }

    def update(Carro carro) {
        if (carro == null) {
            notFound()
            return
        }

        try {
            carroService.save(carro)
        } catch (ValidationException e) {
            respond carro.errors, view:'edit'
            return
        }

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.updated.message', args: [message(code: 'carro.label', default: 'Carro'), carro.id])
                redirect carro
            }
            '*'{ respond carro, [status: OK] }
        }
    }

    def delete(Long id) {
        if (id == null) {
            notFound()
            return
        }

        carroService.delete(id)

        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.deleted.message', args: [message(code: 'carro.label', default: 'Carro'), id])
                redirect action:"index", method:"GET"
            }
            '*'{ render status: NO_CONTENT }
        }
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'carro.label', default: 'Carro'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
